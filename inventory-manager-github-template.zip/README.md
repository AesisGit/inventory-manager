# Inventory Manager (Google Sheets Add-on)
A collaborative inventory management tool powered by Google Apps Script.

## Features
- Add, search, and manage inventory with sidebar UIs
- Barcode scanning, low stock detection, audit log
- Mobile-friendly dashboard and guided workflows

## Setup
1. Open Google Sheets > Extensions > Apps Script
2. Copy files from `src/` into your Apps Script project
3. Run `setupInventorySheets_withSamples.gs` in `setup/` to initialize sheets

## Deploy
- As Google Workspace Add-on
- Or pair with mobile apps in `mobile/`

Template prepared for @AesisGit
